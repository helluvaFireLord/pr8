﻿using System;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;
using System.Xml.Linq;
using Мод.Разр.Пецевич_ПР22_102_практ3.Models;
using Мод.Разр.Пецевич_ПР22_102_практ3.Pages;
using Мод.Разр.Пецевич_ПР22_102_практ3.Services;

namespace Мод.Разр.Пецевич_ПР22_102_практ3
{
    public partial class Autho : Page
    {
        int click;
        int unlockTime; 
        DispatcherTimer timer; 

        public Autho()
        {
            InitializeComponent();
            click = 0;
            unlockTime = 0;
            tbTimer.Foreground = new SolidColorBrush(Colors.Red);
            tbTimer.Visibility = Visibility.Hidden;

            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(1);
            timer.Tick += Tick;
        }

        private void Tick(object sender, EventArgs e)
        {
            unlockTime--;
            if (unlockTime > 0)
            {
                tbTimer.Text = $"Окно разблокируется через {unlockTime} секунд";
            }
            else
            {
                timer.Stop();
                UnlockControls();
            }
        }

        private void UnlockControls()
        {
            tbLogin.IsEnabled = true;
            tbPassword.IsEnabled = true;
            tbCaptcha.IsEnabled = true;
            btnEnter.IsEnabled = true;
            btnEnterGuest.IsEnabled = true;
            tbTimer.Visibility = Visibility.Hidden;
            tbTimer.Text = string.Empty;
            click = 0;
        }

        private void LockControls()
        {
            tbLogin.IsEnabled = false;
            tbPassword.IsEnabled = false;
            tbCaptcha.IsEnabled = false;
            btnEnter.IsEnabled = false;
            btnEnterGuest.IsEnabled = false;
            tbTimer.Visibility = Visibility.Visible;
        }

        public static string HashPassword(string password)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] sourceBytePassword = Encoding.UTF8.GetBytes(password);
                byte[] hash = sha256Hash.ComputeHash(sourceBytePassword);
                return BitConverter.ToString(hash).Replace("-", String.Empty);
            }
        }

        private void btnEnterGuest_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Client1(null, null));
        }

        private void GenerateCaptcha()
        {
            tbCaptcha.Visibility = Visibility.Visible;
            tblCaptcha.Visibility = Visibility.Visible;

            string captchaText = CaptchaGenerator.GenerateCaptchaText(6);
            tblCaptcha.Text = captchaText;
            tblCaptcha.TextDecorations = TextDecorations.Strikethrough;
        }

        private bool IsWorkTime()
        {
//
            TimeSpan currentTime = DateTime.Now.TimeOfDay;
            TimeSpan workStart = new TimeSpan(10, 0, 0);
            TimeSpan workEnd = new TimeSpan(19, 0, 0);

            return currentTime >= workStart && currentTime <= workEnd;
        }
//
        private string GetGreetingMessage(string firstName, string lastName, string secondName)
        {
//
            TimeSpan currentTime = DateTime.Now.TimeOfDay;
            string timeOfDay = "Доброе утро";

            if (currentTime >= new TimeSpan(12, 1, 0) && currentTime <= new TimeSpan(17, 0, 0))
            {
                timeOfDay = "Добрый день";
            }
            else if (currentTime >= new TimeSpan(17, 1, 0) && currentTime <= new TimeSpan(19, 0, 0))
            {
                timeOfDay = "Добрый вечер";
            }
//
            return $"{timeOfDay}, {lastName} {firstName} {secondName}!";
        }

        private void btnEnter_Click(object sender, RoutedEventArgs e)
        {
//
            if (!IsWorkTime())
            {
                MessageBox.Show("Система недоступна. Доступ разрешен только с 10:00 до 19:00.");
                return;
            }
//
            if (unlockTime > 0)
            {
                MessageBox.Show("Окно заблокировано. Пожалуйста, подождите.");
                return;
            }

            click++;
            string login = tbLogin.Text.Trim();
            string password = HashPassword(tbPassword.Text.Trim());
            var db = ХлебопекарняEntities1.GetContext();

            var user = db.Authorization.FirstOrDefault(x => x.Login == login && x.Password == password);


            if (click <= 3)
            {
                if (user != null && (click == 1 || tbCaptcha.Text == tblCaptcha.Text))
                {
                    var emp = db.Employees.Where(x => x.Authorization_ID == user.Authorization_ID).FirstOrDefault();

                    string greeting = GetGreetingMessage(emp.Second_name, emp.First_name, emp.Last_name);
                    MessageBox.Show(greeting);

                    MessageBox.Show($"Вы вошли под: {user.Roles.Role}");
                    LoadPage(user.Roles.Role, user);
                }
                else
                {
                    MessageBox.Show("Неверный логин, пароль или капча.");
                    tbPassword.Clear();
                    tbCaptcha.Clear();
                    GenerateCaptcha();
                }
            }

            if (click > 3)
            {
                MessageBox.Show("Превышено количество попыток! Окно заблокировано на 10 секунд.");
                LockControls();
                unlockTime = 10;
                tbTimer.Text = $"Окно разблокируется через {unlockTime} секунд";
                timer.Start();
            }
        }

        private void LoadPage(string role, Authorization user)
        {
            click = 0;
            tblCaptcha.Visibility = Visibility.Hidden;
            tbCaptcha.Clear();
            tbLogin.Clear();
            tbPassword.Clear();
            tbCaptcha.Visibility = Visibility.Hidden;

            switch (role)
            {
                case "Клиент":
                    NavigationService.Navigate(new Client1(user, role));
                    break;
                case "Администратор":
                    NavigationService.Navigate(new Admin(user, role));
                    break;
                case "Управляющий":
                    NavigationService.Navigate(new Manager(user, role));
                    break;
                default:
                    MessageBox.Show("Роль не распознана!");
                    break;
            }
        }
    }
}
